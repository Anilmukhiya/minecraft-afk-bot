# MUKHIYA9734 Minecraft AFK Bot

Mineflayer bot for an offline/cracked Minecraft server. It:

- Uses offline authentication (`auth: 'offline'`)
- Automatically detects the server's Minecraft protocol version
- Sends `/login <password>` after joining
- Detects delayed login prompts and sends the login command once
- Performs small AFK movements/camera changes
- Automatically reconnects after disconnects/kicks/errors
- Works as a Render Background Worker

## Important

Render's Free plan does **not** provide always-on Background Workers. For a real 24/7 bot, create this as a paid Background Worker. Render Free Web Services can spin down after 15 minutes without inbound traffic, so a Free Web Service is not a reliable 24/7 solution.

## Local setup

1. Install Node.js 20 or 22.
2. Copy `.env.example` to `.env`.
3. Put your actual server password in `.env`.
4. Run:

```bash
npm install
npm start
```

## Render setup

1. Push this repository to GitHub.
2. In Render, choose **New > Blueprint** and select the GitHub repository.
3. Render reads `render.yaml`.
4. When Render asks for `MC_PASSWORD`, enter the password for the in-game `/login` command.
5. Deploy.
6. Open the Render logs. You should see `[CONNECT]`, then `[ONLINE]` after the bot joins.

## Version support

`MC_VERSION=auto` is intentional. Mineflayer documents that if no version is specified, it guesses the server version automatically. This is preferable for a server that may change between Minecraft 1.21.x releases.

If the server rejects the protocol, change `MC_VERSION` to the exact version reported by the server, for example `1.21.8`, provided your installed Mineflayer version supports it.

## Login command

The code assumes the account is already registered and the server uses:

```text
/login <password>
```

Change `MC_LOGIN_COMMAND` if the server uses a different command.
