require('dotenv').config()

const mineflayer = require('mineflayer')

const HOST = process.env.MC_HOST || 'play.oneforall.social'
const PORT = Number(process.env.MC_PORT || 25565)
const USERNAME = process.env.MC_USERNAME || 'MUKHIYA9734'
const PASSWORD = process.env.MC_PASSWORD || ''
const LOGIN_COMMAND = process.env.MC_LOGIN_COMMAND || '/login'
const VERSION_ENV = (process.env.MC_VERSION || 'auto').trim().toLowerCase()
const VERSION = VERSION_ENV === 'auto' || VERSION_ENV === 'false' ? false : VERSION_ENV

const RECONNECT_MIN_MS = Number(process.env.RECONNECT_MIN_MS || 5000)
const RECONNECT_MAX_MS = Number(process.env.RECONNECT_MAX_MS || 60000)
const ANTI_AFK_INTERVAL_MS = Number(process.env.ANTI_AFK_INTERVAL_MS || 30000)
const LOGIN_DELAY_MS = Number(process.env.LOGIN_DELAY_MS || 2500)

let bot = null
let reconnectTimer = null
let reconnectDelay = RECONNECT_MIN_MS
let afkTimer = null
let loginTimer = null
let loginSent = false
let shuttingDown = false
let afkPhase = 0

function log(...args) {
  console.log(new Date().toISOString(), ...args)
}

function clearTimers() {
  if (reconnectTimer) {
    clearTimeout(reconnectTimer)
    reconnectTimer = null
  }
  if (afkTimer) {
    clearInterval(afkTimer)
    afkTimer = null
  }
  if (loginTimer) {
    clearTimeout(loginTimer)
    loginTimer = null
  }
}

function safeReason(reason) {
  if (reason == null) return ''
  if (typeof reason === 'string') return reason
  try {
    return JSON.stringify(reason)
  } catch {
    return String(reason)
  }
}

function sendLogin(source = 'automatic') {
  if (!bot || !bot.player || !PASSWORD || loginSent) return

  loginSent = true
  const command = `${LOGIN_COMMAND} ${PASSWORD}`.trim()

  log(`[AUTH] Sending login command (${source}).`)
  bot.chat(command)
}

function startAfkLoop() {
  if (!bot || afkTimer) return

  afkTimer = setInterval(() => {
    if (!bot || !bot.entity || !bot.player) return

    afkPhase = (afkPhase + 1) % 4

    // Small, low-risk activity intended to reduce AFK kicks.
    // We rotate the camera every cycle and briefly strafe/step.
    const yaw = bot.entity.yaw + Math.PI / 2
    const pitch = Math.max(-0.35, Math.min(0.35, bot.entity.pitch || 0))

    bot.look(yaw, pitch, true).catch(() => {})

    if (afkPhase === 1) {
      bot.setControlState('left', true)
      setTimeout(() => bot?.setControlState('left', false), 1500)
    } else if (afkPhase === 2) {
      bot.setControlState('right', true)
      setTimeout(() => bot?.setControlState('right', false), 1500)
    } else if (afkPhase === 3) {
      bot.setControlState('forward', true)
      setTimeout(() => bot?.setControlState('forward', false), 1200)
    } else {
      bot.setControlState('back', true)
      setTimeout(() => bot?.setControlState('back', false), 1200)
    }
  }, ANTI_AFK_INTERVAL_MS)
}

function scheduleReconnect(reason) {
  if (shuttingDown || reconnectTimer) return

  clearTimers()
  log(`[RECONNECT] ${reason}. Reconnecting in ${Math.round(reconnectDelay / 1000)}s...`)

  reconnectTimer = setTimeout(() => {
    reconnectTimer = null
    connect()
  }, reconnectDelay)

  reconnectDelay = Math.min(Math.round(reconnectDelay * 1.7), RECONNECT_MAX_MS)
}

function resetReconnectDelay() {
  reconnectDelay = RECONNECT_MIN_MS
}

function connect() {
  if (shuttingDown) return

  clearTimers()
  loginSent = false
  afkPhase = 0

  log(`[CONNECT] ${USERNAME} -> ${HOST}:${PORT}`)
  log(`[CONNECT] Minecraft version: ${VERSION === false ? 'auto-detect' : VERSION}`)

  bot = mineflayer.createBot({
    host: HOST,
    port: PORT,
    username: USERNAME,
    auth: 'offline',
    version: VERSION,
    keepAlive: true,
    checkTimeoutInterval: 30000,
    logErrors: true,
    hideErrors: false
  })

  bot.once('spawn', () => {
    resetReconnectDelay()
    log(`[ONLINE] ${USERNAME} spawned successfully.`)

    loginTimer = setTimeout(() => sendLogin('spawn'), LOGIN_DELAY_MS)
    startAfkLoop()
  })

  // Some login plugins only show the prompt after the player has fully joined.
  bot.on('messagestr', (message) => {
    const text = String(message || '').toLowerCase()

    if (!PASSWORD || loginSent) return

    const loginPrompt =
      text.includes('/login') ||
      text.includes('please login') ||
      text.includes('please log in') ||
      text.includes('type your password') ||
      text.includes('use /login')

    if (loginPrompt) {
      sendLogin('server prompt')
    }
  })

  bot.on('chat', (username, message) => {
    if (username === USERNAME) return
    log(`[CHAT] <${username}> ${message}`)
  })

  bot.on('kicked', (reason) => {
    log(`[KICKED] ${safeReason(reason)}`)
  })

  bot.on('error', (err) => {
    log(`[ERROR] ${err?.stack || err}`)
  })

  bot.once('end', (reason) => {
    log(`[END] Connection closed: ${safeReason(reason) || 'unknown reason'}`)
    scheduleReconnect('connection ended')
  })
}

function shutdown(signal) {
  if (shuttingDown) return
  shuttingDown = true
  clearTimers()
  log(`[SHUTDOWN] ${signal}`)

  try {
    bot?.quit('Shutting down')
  } catch {}

  setTimeout(() => process.exit(0), 500)
}

process.on('SIGTERM', () => shutdown('SIGTERM'))
process.on('SIGINT', () => shutdown('SIGINT'))

process.on('unhandledRejection', (err) => {
  log(`[UNHANDLED_REJECTION] ${err?.stack || err}`)
})

process.on('uncaughtException', (err) => {
  log(`[UNCAUGHT_EXCEPTION] ${err?.stack || err}`)
})

if (!PASSWORD) {
  log('[WARNING] MC_PASSWORD is empty. The bot will connect, but it will not send /login.')
}

connect()
